// 1. Write a function to negate the number passed to it:
// - 5 ==> -5
// - -100  ==> 100

function negateTheNumber(a: number) {
  let b: number = -1;
  let negate = a * b;
  return negate;
}

console.log(negateTheNumber(5));
console.log(negateTheNumber(-100))